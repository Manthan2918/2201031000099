/* fonts */
export const FontFamily = {
  poppinsMedium: "Poppins-Medium",
  poppinsSemiBold: "Poppins-SemiBold",
  poppinsBold: "Poppins-Bold",
  judsonBold: "Judson-Bold",
};
/* font sizes */
export const FontSize = {
  size_sm: 14,
  size_smi: 13,
  size_7xl: 26,
  size_13xl: 32,
  size_xl: 20,
  size_9xl: 28,
  size_mini: 15,
  size_3xl: 22,
  size_base: 16,
  size_5xl: 24,
  size_21xl: 40,
  size_6xl: 25,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorBlack: "#000",
  colorCrimson: "#fd1755",
  colorGray_100: "rgba(0, 0, 0, 0.81)",
  colorGray_200: "rgba(0, 0, 0, 0.27)",
  colorGray_300: "rgba(0, 0, 0, 0.76)",
  colorGray_400: "rgba(0, 0, 0, 0.79)",
  colorGray_500: "rgba(0, 0, 0, 0.42)",
  colorGray_600: "rgba(0, 0, 0, 0.32)",
  colorGray_700: "rgba(0, 0, 0, 0.44)",
  colorGray_800: "rgba(0, 0, 0, 0.38)",
  colorGray_900: "rgba(0, 0, 0, 0.31)",
  colorGray_1000: "rgba(255, 255, 255, 0.04)",
  colorGray_1100: "rgba(0, 0, 0, 0.64)",
  colorGray_1200: "rgba(0, 0, 0, 0.75)",
  colorGray_1300: "rgba(0, 0, 0, 0.21)",
  colorGray_1400: "rgba(0, 0, 0, 0.3)",
  colorGray_1500: "rgba(0, 0, 0, 0.33)",
  colorGray_1600: "rgba(0, 0, 0, 0.89)",
  colorGray_1700: "rgba(0, 0, 0, 0.26)",
  colorGray_1800: "rgba(0, 0, 0, 0.23)",
  colorGainsboro_100: "#d9dce1",
  colorGainsboro_200: "#d9d9d9",
};
/* Paddings */
export const Padding = {
  p_14xl: 33,
  p_7xs: 6,
};
/* border radiuses */
export const Border = {
  br_11xs_3: 1,
  br_10xs_7: 3,
  br_8xs: 5,
  br_3xs: 10,
  br_7xs: 6,
};
