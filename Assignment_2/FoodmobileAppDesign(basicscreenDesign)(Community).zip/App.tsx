const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import Frame from "./screens/Frame";
import Manthan from "./screens/Manthan";
import GroupComponent1 from "./components/GroupComponent1";
import IPhone13ProMax from "./screens/IPhone13ProMax";
import IPhone13ProMax1 from "./screens/IPhone13ProMax1";
import IPhone13ProMax2 from "./screens/IPhone13ProMax2";
import IPhone13ProMax3 from "./screens/IPhone13ProMax3";
import IPhone13ProMax4 from "./screens/IPhone13ProMax4";
import IPhone13ProMax5 from "./screens/IPhone13ProMax5";
import IPhone13ProMax6 from "./screens/IPhone13ProMax6";
import IPhone13ProMax7 from "./screens/IPhone13ProMax7";
import IPhone13ProMax8 from "./screens/IPhone13ProMax8";
import IPhone13ProMax9 from "./screens/IPhone13ProMax9";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
    "Poppins-SemiBold": require("./assets/fonts/Poppins-SemiBold.ttf"),
    "Poppins-Bold": require("./assets/fonts/Poppins-Bold.ttf"),
    "Judson-Bold": require("./assets/fonts/Judson-Bold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Frame"
              component={Frame}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Manthan"
              component={Manthan}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax"
              component={IPhone13ProMax}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax1"
              component={IPhone13ProMax1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax2"
              component={IPhone13ProMax2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax3"
              component={IPhone13ProMax3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax4"
              component={IPhone13ProMax4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax5"
              component={IPhone13ProMax5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax6"
              component={IPhone13ProMax6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax7"
              component={IPhone13ProMax7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax8"
              component={IPhone13ProMax8}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone13ProMax9"
              component={IPhone13ProMax9}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
