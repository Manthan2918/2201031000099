import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, Border } from "../GlobalStyles";

const GoogleBox = () => {
  return (
    <View style={styles.groupParent}>
      <View style={[styles.groupChildLayout1, styles.groupChildLayout1]}>
        <View style={[styles.groupPosition1, styles.groupChildLayout1]}>
          <View
            style={[
              styles.groupChild5,
              styles.groupChildShadowBox1,
              styles.groupPosition1,
            ]}
          />
          <Image
            style={styles.image3Icon}
            contentFit="cover"
            source={require("../assets/image-31.png")}
          />
          <Text
            style={[styles.facebook, styles.googleTypo, styles.google1Position]}
          >
            facebook
          </Text>
        </View>
      </View>
      <View style={[styles.rectangleParent3, styles.groupChildLayout1]}>
        <View
          style={[
            styles.groupChild5,
            styles.groupChildShadowBox1,
            styles.groupPosition1,
          ]}
        />
        <Image
          style={[styles.image2Icon1, styles.image2IconLayout]}
          contentFit="cover"
          source={require("../assets/image-21.png")}
        />
        <Text
          style={[styles.google1, styles.googleTypo, styles.google1Position]}
        >
          Google
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout1: {
    width: 161,
    height: 57,
  },
  groupPosition1: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  google1Position: {
    color: Color.colorGray_400,
    top: 20,
    position: "absolute",
  },
  groupChild5: {
    elevation: 17,
    shadowRadius: 17,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    width: 161,
    height: 57,
  },
  image3Icon: {
    top: 13,
    left: 26,
    borderRadius: Border.br_7xs,
    width: 32,
    height: 32,
    position: "absolute",
  },
  facebook: {
    left: 69,
  },
  image2Icon1: {
    top: 9,
    left: 34,
    position: "absolute",
  },
  google1: {
    left: 77,
  },
  rectangleParent3: {
    marginLeft: 48,
  },
  groupParent: {
    top: 344,
    left: 29,
    flexDirection: "row",
    position: "absolute",
  },
});

export default GoogleBox;
