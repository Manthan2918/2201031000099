import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

export type GroupComponent1Type = {
  cellularConnection?: ImageSourcePropType;
  wifi?: ImageSourcePropType;
  cap?: ImageSourcePropType;

  /** Style props */
  groupViewPosition?: string;
  groupViewWidth?: number | string;
  groupViewHeight?: number | string;
  groupViewTop?: number | string;
  groupViewRight?: number | string;
  groupViewBottom?: number | string;
  groupViewLeft?: number | string;
  timeWidth?: number | string;
  timeFontSize?: number;
  cellularConnectionIconWidth?: number | string;
  wifiIconWidth?: number | string;
  batteryWidth?: number | string;
  batteryLeft?: number | string;
  borderWidth?: number | string;
  borderRight?: number | string;
  capIconWidth?: number | string;
  capIconLeft?: number | string;
  capIconRight?: number | string;
  capacityWidth?: number | string;
  capacityRight?: number | string;
  capacityLeft?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent1 = ({
  cellularConnection,
  wifi,
  cap,
  groupViewPosition,
  groupViewWidth,
  groupViewHeight,
  groupViewTop,
  groupViewRight,
  groupViewBottom,
  groupViewLeft,
  timeWidth,
  timeFontSize,
  cellularConnectionIconWidth,
  wifiIconWidth,
  batteryWidth,
  batteryLeft,
  borderWidth,
  borderRight,
  capIconWidth,
  capIconLeft,
  capIconRight,
  capacityWidth,
  capacityRight,
  capacityLeft,
}: GroupComponent1Type) => {
  const groupViewStyle = useMemo(() => {
    return {
      ...getStyleValue("position", groupViewPosition),
      ...getStyleValue("width", groupViewWidth),
      ...getStyleValue("height", groupViewHeight),
      ...getStyleValue("top", groupViewTop),
      ...getStyleValue("right", groupViewRight),
      ...getStyleValue("bottom", groupViewBottom),
      ...getStyleValue("left", groupViewLeft),
    };
  }, [
    groupViewPosition,
    groupViewWidth,
    groupViewHeight,
    groupViewTop,
    groupViewRight,
    groupViewBottom,
    groupViewLeft,
  ]);

  const timeStyle = useMemo(() => {
    return {
      ...getStyleValue("width", timeWidth),
      ...getStyleValue("fontSize", timeFontSize),
    };
  }, [timeWidth, timeFontSize]);

  const cellularConnectionIconStyle = useMemo(() => {
    return {
      ...getStyleValue("width", cellularConnectionIconWidth),
    };
  }, [cellularConnectionIconWidth]);

  const wifiIconStyle = useMemo(() => {
    return {
      ...getStyleValue("width", wifiIconWidth),
    };
  }, [wifiIconWidth]);

  const batteryStyle = useMemo(() => {
    return {
      ...getStyleValue("width", batteryWidth),
      ...getStyleValue("left", batteryLeft),
    };
  }, [batteryWidth, batteryLeft]);

  const borderStyle = useMemo(() => {
    return {
      ...getStyleValue("width", borderWidth),
      ...getStyleValue("right", borderRight),
    };
  }, [borderWidth, borderRight]);

  const capIconStyle = useMemo(() => {
    return {
      ...getStyleValue("width", capIconWidth),
      ...getStyleValue("left", capIconLeft),
      ...getStyleValue("right", capIconRight),
    };
  }, [capIconWidth, capIconLeft, capIconRight]);

  const capacityStyle = useMemo(() => {
    return {
      ...getStyleValue("width", capacityWidth),
      ...getStyleValue("right", capacityRight),
      ...getStyleValue("left", capacityLeft),
    };
  }, [capacityWidth, capacityRight, capacityLeft]);

  return (
    <View style={[styles.timeParent, groupViewStyle]}>
      <Text style={[styles.time, styles.timePosition, timeStyle]}>9:41</Text>
      <Image
        style={[styles.cellularConnectionIcon, cellularConnectionIconStyle]}
        contentFit="cover"
        source={cellularConnection}
      />
      <Image
        style={[styles.wifiIcon, wifiIconStyle]}
        contentFit="cover"
        source={wifi}
      />
      <View style={[styles.battery, styles.batteryPosition, batteryStyle]}>
        <View style={[styles.border, styles.timePosition, borderStyle]} />
        <Image
          style={[styles.capIcon, styles.batteryPosition, capIconStyle]}
          contentFit="cover"
          source={cap}
        />
        <View style={[styles.capacity, capacityStyle]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  timePosition: {
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  batteryPosition: {
    right: "0%",
    position: "absolute",
  },
  time: {
    width: "14.13%",
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorBlack,
    textAlign: "center",
  },
  cellularConnectionIcon: {
    width: 17,
    height: 11,
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  border: {
    height: "100%",
    width: "90.53%",
    right: "9.47%",
    bottom: "0%",
    borderRadius: 3,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 1,
    opacity: 0.35,
  },
  capIcon: {
    height: "35.4%",
    width: "5.35%",
    top: "32.74%",
    bottom: "31.86%",
    left: "94.65%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    opacity: 0.4,
  },
  capacity: {
    height: "64.6%",
    width: "74.07%",
    top: "17.7%",
    right: "17.7%",
    bottom: "17.7%",
    left: "8.23%",
    borderRadius: 1,
    backgroundColor: Color.colorBlack,
    position: "absolute",
  },
  battery: {
    height: "49.13%",
    width: "6.36%",
    top: "33.91%",
    bottom: "16.96%",
    left: "93.64%",
  },
  timeParent: {
    width: 382,
    height: 23,
  },
});

export default GroupComponent1;
