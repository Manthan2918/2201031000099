import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, FontFamily } from "../GlobalStyles";

const ContainerWrapper = () => {
  return (
    <View
      style={[
        styles.groupParent1,
        styles.groupChildShadowBox1,
        styles.groupShadowBox,
      ]}
    >
      <View style={styles.rectangleParentLayout}>
        <View style={[styles.groupChildShadowBox, styles.groupShadowBox]} />
        <Text style={[styles.text42, styles.text42Typo]}>4</Text>
      </View>
      <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
        <View style={[styles.groupChildShadowBox, styles.groupShadowBox]} />
        <Text style={[styles.text42, styles.text42Typo]}>9</Text>
      </View>
      <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
        <View style={[styles.groupChildShadowBox, styles.groupShadowBox]} />
        <Text style={[styles.text42, styles.text42Typo]}>6</Text>
      </View>
      <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
        <View style={[styles.groupChildShadowBox, styles.groupShadowBox]} />
        <Text style={[styles.text42, styles.text42Typo]}>7</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupShadowBox: {
    position: "absolute",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 1,
  },
  groupChildShadowBox: {
    elevation: 12,
    shadowRadius: 12,
    backgroundColor: Color.colorGray_1000,
    bottom: "0%",
    height: "100%",
    right: "0%",
    left: "0%",
    top: "0%",
    width: "100%",
  },
  text42: {
    top: "11.42%",
    left: "34.12%",
    color: Color.colorGray_1100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  rectangleParentLayout: {
    height: 54,
    width: 60,
  },
  rectangleParent6: {
    marginLeft: 35,
  },
  groupParent1: {
    top: 297,
    shadowRadius: 4,
    elevation: 4,
    flexDirection: "row",
    left: 42,
  },
});

export default ContainerWrapper;
