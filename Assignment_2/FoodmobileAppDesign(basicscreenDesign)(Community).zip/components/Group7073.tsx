import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";

const DataContainer = () => {
  return (
    <View style={styles.iphone13ProMax2Inner}>
      <View style={[styles.groupChildPosition, styles.foodu1Layout]}>
        <View style={[styles.groupChildPosition, styles.foodu1Layout]}>
          <Image
            style={[
              styles.vectorIcon1,
              styles.vectorIconLayout,
              styles.vectorIcon1Position,
            ]}
            contentFit="cover"
            source={require("../assets/vector1.png")}
          />
          <Text style={[styles.foodu1, styles.fooduTypo, styles.foodu1Layout]}>
            FOODU
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  foodu1Layout: {
    width: "100%",
    left: "0%",
  },
  vectorIcon1Position: {
    top: "0%",
    right: "0%",
    position: "absolute",
  },
  vectorIcon1: {
    height: "60.05%",
    width: "99.51%",
    bottom: "39.95%",
    left: "0.49%",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  foodu1: {
    top: "71.81%",
  },
  groupChildPosition: {
    bottom: "0%",
    height: "100%",
    top: "0%",
    right: "0%",
    position: "absolute",
  },
  iphone13ProMax2Inner: {
    height: "18%",
    top: "12.7%",
    right: "36.93%",
    bottom: "69.3%",
    left: "35.03%",
    width: "28.04%",
    position: "absolute",
  },
});

export default DataContainer;
