import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const EmailFormContainer = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={[styles.iphone13ProMax4Inner, styles.groupLayout]}
      onPress={() => navigation.navigate("IPhone13ProMax4")}
    >
      <View style={[styles.groupPosition2, styles.groupLayout]}>
        <View style={[styles.groupPosition2, styles.groupLayout]}>
          <View
            style={[
              styles.groupChild7,
              styles.groupLayout,
              styles.groupPosition2,
            ]}
          />
          <Text style={[styles.goToEmail, styles.updateClr]}>Go to Email</Text>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  groupPosition2: {
    top: 0,
    left: 0,
  },
  groupChild7: {
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_8xs,
  },
  goToEmail: {
    left: 89,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
    top: 10,
  },
  iphone13ProMax4Inner: {
    top: 630,
    left: 68,
  },
});

export default EmailFormContainer;
