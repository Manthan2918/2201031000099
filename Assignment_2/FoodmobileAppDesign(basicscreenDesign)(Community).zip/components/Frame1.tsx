import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, Border, Padding } from "../GlobalStyles";

const GoogleContainer = () => {
  return (
    <View style={styles.groupParent}>
      <View style={styles.groupChildLayout}>
        <View style={[styles.groupPosition, styles.groupChildLayout1]}>
          <View
            style={[
              styles.groupChild3,
              styles.groupChildShadowBox1,
              styles.groupChild3ShadowBox,
            ]}
          />
          <Image
            style={styles.image3Icon}
            contentFit="cover"
            source={require("../assets/image-3.png")}
          />
          <Text style={[styles.facebook, styles.googleTypo]}>facebook</Text>
        </View>
      </View>
      <View
        style={[
          styles.image2Parent,
          styles.groupChildShadowBox1,
          styles.groupChild3ShadowBox,
        ]}
      >
        <Image
          style={styles.image2IconLayout}
          contentFit="cover"
          source={require("../assets/image-2.png")}
        />
        <Text style={[styles.google, styles.googleTypo]}>Google</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChild3ShadowBox: {
    backgroundColor: Color.colorWhite,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 1,
    borderRadius: Border.br_3xs,
    shadowRadius: 17,
    elevation: 17,
  },
  groupChild3: {
    top: 0,
    left: 0,
    position: "absolute",
    width: 161,
    height: 57,
  },
  image3Icon: {
    top: 13,
    left: 26,
    borderRadius: Border.br_7xs,
    width: 32,
    height: 32,
    position: "absolute",
  },
  facebook: {
    left: 69,
    top: 20,
    color: Color.colorGray_400,
    position: "absolute",
  },
  groupPosition: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  groupChildLayout: {
    width: 161,
    height: 57,
  },
  image2IconLayout: {
    height: 41,
    width: 38,
  },
  google: {
    marginLeft: 5,
  },
  image2Parent: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_7xs,
    marginLeft: 41,
    alignItems: "center",
    flexDirection: "row",
  },
  groupParent: {
    top: 344,
    left: 29,
    position: "absolute",
    flexDirection: "row",
  },
});

export default GoogleContainer;
