import * as React from "react";
import { StyleSheet, View } from "react-native";

const Frame = () => {
  return <View style={styles.frameView} />;
};

const styles = StyleSheet.create({
  frameView: {
    backgroundColor: "#c8b6ff",
    flex: 1,
    width: "100%",
    height: 3128,
    overflow: "hidden",
  },
});

export default Frame;
