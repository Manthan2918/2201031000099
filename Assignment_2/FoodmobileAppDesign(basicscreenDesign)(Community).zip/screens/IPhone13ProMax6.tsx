import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import GroupComponent1 from "../components/GroupComponent1";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const IPhone13ProMax6 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax7}>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector4.png")}
      />
      <Text style={styles.registerToFoodu}>Register to foodu</Text>
      <View style={styles.frameParent}>
        <View style={[styles.fullNameParent, styles.groupChildPosition]}>
          <Text style={styles.emailTypo}>Full Name</Text>
          <Text style={[styles.email, styles.emailTypo]}>Email</Text>
          <Text style={[styles.email, styles.emailTypo]}>Mobile Number</Text>
          <Text style={[styles.email, styles.emailTypo]}>Password</Text>
          <Text style={[styles.email, styles.emailTypo]}>Confirm Password</Text>
        </View>
        <View style={styles.lineParent}>
          <View style={styles.frameLayout} />
          <View style={[styles.frameItem, styles.frameLayout]} />
          <View style={[styles.frameItem, styles.frameLayout]} />
          <View style={[styles.frameItem, styles.frameLayout]} />
          <View style={[styles.frameItem, styles.frameLayout]} />
        </View>
      </View>
      <Pressable
        style={[styles.rectangleParent, styles.groupChildLayout]}
        onPress={() => navigation.navigate("IPhone13ProMax3")}
      >
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={styles.register}>Register</Text>
      </Pressable>
      <Text style={[styles.byRegisteringYouContainer, styles.containerTypo]}>
        <Text style={styles.byRegisteringYou}>By registering you agree to</Text>
        <Text style={styles.termsConditions}>{` Terms & conditions`}</Text>
      </Text>
      <Text style={[styles.andPrivacyPolicyContainer, styles.containerTypo]}>
        <Text style={styles.byRegisteringYou}> and</Text>
        <Text style={styles.termsConditions}> privacy Policy</Text>
        <Text style={styles.byRegisteringYou}> of the foodu</Text>
      </Text>
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection6.png")}
        wifi={require("../assets/wifi6.png")}
        cap={require("../assets/cap6.png")}
        groupViewPosition="absolute"
        groupViewWidth="97.42%"
        groupViewHeight="2.48%"
        groupViewTop="0.82%"
        groupViewRight="2.58%"
        groupViewBottom="96.7%"
        groupViewLeft="0%"
        timeWidth="14.13%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.36%"
        batteryLeft="93.64%"
        borderWidth="90.41%"
        borderRight="9.59%"
        capIconWidth="5.54%"
        capIconLeft="94.46%"
        capIconRight="0%"
        capacityWidth="74.17%"
        capacityRight="17.71%"
        capacityLeft="8.12%"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildPosition: {
    top: 0,
    left: 0,
  },
  emailTypo: {
    color: Color.colorGray_1300,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
  },
  frameLayout: {
    height: 1,
    width: 319,
    borderTopWidth: 1,
    borderColor: Color.colorGray_1400,
    borderStyle: "solid",
  },
  groupChildLayout: {
    height: 50,
    width: 343,
    position: "absolute",
  },
  containerTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.25%",
    width: "3.27%",
    top: "8.42%",
    right: "88.7%",
    bottom: "89.33%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "8.03%",
    position: "absolute",
    overflow: "hidden",
  },
  registerToFoodu: {
    width: "57.01%",
    top: "14.55%",
    fontSize: FontSize.size_9xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorBlack,
    textAlign: "left",
    left: "8.03%",
    position: "absolute",
  },
  email: {
    marginTop: 58,
  },
  fullNameParent: {
    left: 0,
    position: "absolute",
  },
  frameItem: {
    marginTop: 79,
  },
  lineParent: {
    top: 43,
    alignItems: "center",
    left: 0,
    position: "absolute",
  },
  frameParent: {
    top: 219,
    width: 318,
    height: 359,
    left: 41,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorGainsboro_100,
    left: 0,
    top: 0,
  },
  register: {
    top: 10,
    left: 134,
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 671,
    left: 41,
  },
  byRegisteringYou: {
    color: Color.colorGray_1500,
  },
  termsConditions: {
    color: Color.colorCrimson,
  },
  byRegisteringYouContainer: {
    top: 764,
    left: 61,
  },
  andPrivacyPolicyContainer: {
    top: 794,
    left: 64,
  },
  iphone13ProMax7: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax6;
