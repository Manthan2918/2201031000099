import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import DataContainer from "../components/DataContainer";
import GroupComponent1 from "../components/GroupComponent1";
import GoogleBox from "../components/GoogleBox";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const IPhone13ProMax8 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax3}>
      <DataContainer dimensionsCode={require("../assets/vector2.png")} />
      <Image
        style={[styles.unionIcon, styles.unionIconPosition]}
        contentFit="cover"
        source={require("../assets/union.png")}
      />
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection3.png")}
        wifi={require("../assets/wifi3.png")}
        cap={require("../assets/cap3.png")}
        groupViewPosition="absolute"
        groupViewWidth="96.25%"
        groupViewHeight="2.48%"
        groupViewTop="0.86%"
        groupViewRight="2.81%"
        groupViewBottom="96.65%"
        groupViewLeft="0.94%"
        timeWidth="14.14%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.37%"
        batteryLeft="93.63%"
        borderWidth="90.3%"
        borderRight="9.7%"
        capIconWidth="5.6%"
        capIconLeft="94.4%"
        capIconRight="0%"
        capacityWidth="73.88%"
        capacityRight="17.91%"
        capacityLeft="8.21%"
      />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={styles.login}>Login</Text>
      </View>
      <GoogleBox />
      <Text style={styles.or}>Or</Text>
      <Text style={[styles.password, styles.emailIdTypo]}>Password</Text>
      <View style={[styles.iphone13ProMax3Child, styles.iphone13Layout]} />
      <Text style={[styles.emailId, styles.emailIdTypo]}>Email id</Text>
      <View style={[styles.iphone13ProMax3Item, styles.iphone13Layout]} />
      <Pressable
        style={styles.forgotPassword}
        onPress={() => navigation.navigate("IPhone13ProMax7")}
      >
        <Text style={[styles.forgotPassword1, styles.forgotPassword1Typo]}>
          forgot password?
        </Text>
      </Pressable>
      <Text style={[styles.dontHaveAnContainer, styles.forgotPassword1Typo]}>
        <Text style={styles.dontHaveAn}>dont have an account?</Text>
        <Text style={styles.registerNow}>{`register now `}</Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  unionIconPosition: {
    left: 0,
    top: 0,
  },
  groupChildLayout: {
    height: 50,
    width: 343,
    position: "absolute",
  },
  emailIdTypo: {
    color: Color.colorGray_600,
    textTransform: "uppercase",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  iphone13Layout: {
    height: 1,
    width: 339,
    borderTopWidth: 1,
    borderStyle: "solid",
    left: 41,
    position: "absolute",
  },
  forgotPassword1Typo: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  unionIcon: {
    width: 0,
    height: 0,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorGainsboro_100,
    left: 0,
    top: 0,
  },
  login: {
    top: 5,
    left: 138,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 740,
    left: 43,
  },
  or: {
    top: 429,
    left: 201,
    fontSize: FontSize.size_mini,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  password: {
    top: 594,
    left: 42,
  },
  iphone13ProMax3Child: {
    top: 639,
    borderColor: Color.colorGray_500,
  },
  emailId: {
    top: 507,
    left: 43,
  },
  iphone13ProMax3Item: {
    top: 554,
    borderColor: Color.colorGray_700,
  },
  forgotPassword1: {
    textTransform: "lowercase",
    color: Color.colorCrimson,
  },
  forgotPassword: {
    left: 251,
    top: 671,
    position: "absolute",
  },
  dontHaveAn: {
    color: Color.colorGray_800,
  },
  registerNow: {
    color: Color.colorCrimson,
  },
  dontHaveAnContainer: {
    top: 829,
    left: 67,
    textTransform: "capitalize",
    position: "absolute",
  },
  iphone13ProMax3: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax8;
