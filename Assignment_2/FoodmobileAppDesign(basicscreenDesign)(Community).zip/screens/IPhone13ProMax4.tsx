import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import GroupComponent1 from "../components/GroupComponent1";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone13ProMax4 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax5}>
      <Image
        style={styles.unionIcon}
        contentFit="cover"
        source={require("../assets/union.png")}
      />
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection1.png")}
        wifi={require("../assets/wifi1.png")}
        cap={require("../assets/cap1.png")}
        groupViewPosition="absolute"
        groupViewWidth="96.25%"
        groupViewHeight="2.48%"
        groupViewTop="0.86%"
        groupViewRight="2.81%"
        groupViewBottom="96.65%"
        groupViewLeft="0.94%"
        timeWidth="14.14%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.37%"
        batteryLeft="93.63%"
        borderWidth="90.3%"
        borderRight="9.7%"
        capIconWidth="5.6%"
        capIconLeft="94.4%"
        capIconRight="0%"
        capacityWidth="73.88%"
        capacityRight="17.91%"
        capacityLeft="8.21%"
      />
      <Pressable
        style={[styles.rectangleParent, styles.groupChildLayout]}
        onPress={() => navigation.navigate("IPhone13ProMax5")}
      >
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={styles.update}>Update</Text>
      </Pressable>
      <View style={styles.confirmNewPasswordParent}>
        <Text style={[styles.confirmNewPassword, styles.newTypo]}>
          Confirm new password
        </Text>
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text style={[styles.newPassword, styles.newTypo]}>New Password</Text>
        <View style={[styles.groupInner, styles.groupLayout]} />
      </View>
      <Text style={[styles.resetPassword, styles.resetPasswordTypo]}>
        Reset Password
      </Text>
      <Text
        style={[styles.pleaseEnterYour, styles.resetPasswordTypo]}
      >{`please enter your new password and confirm
the password.`}</Text>
      <Image
        style={styles.chevronLeftIcon}
        contentFit="cover"
        source={require("../assets/chevronleft1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 50,
    width: 343,
    position: "absolute",
  },
  newTypo: {
    color: Color.colorGray_600,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textTransform: "capitalize",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  groupLayout: {
    height: 1,
    width: 339,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  resetPasswordTypo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    position: "absolute",
  },
  unionIcon: {
    width: 0,
    height: 0,
    left: 0,
    top: 0,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorGainsboro_100,
    left: 0,
    top: 0,
  },
  update: {
    top: 10,
    left: 134,
    fontSize: FontSize.size_xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 495,
    left: 49,
  },
  confirmNewPassword: {
    top: 87,
    left: 0,
  },
  groupItem: {
    top: 131,
    left: 3,
    borderColor: Color.colorGray_500,
  },
  newPassword: {
    left: 1,
    top: 0,
  },
  groupInner: {
    top: 46,
    borderColor: Color.colorGray_700,
    left: 0,
  },
  confirmNewPasswordParent: {
    top: 302,
    left: 53,
    width: 341,
    height: 131,
    position: "absolute",
  },
  resetPassword: {
    top: 142,
    left: 51,
    fontSize: FontSize.size_6xl,
    color: Color.colorGray_100,
  },
  pleaseEnterYour: {
    top: 199,
    left: 50,
    color: Color.colorGray_200,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  chevronLeftIcon: {
    top: 75,
    left: 36,
    width: 41,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  iphone13ProMax5: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax4;
