import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const Manthan = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.manthan2918}>
      <View style={[styles.iphone13ProMax6, styles.iphone13Layout1]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
        <View style={[styles.timeParent, styles.timeParentLayout]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={[styles.battery, styles.batteryPosition]}>
            <View style={[styles.border, styles.borderBorder]} />
            <Image
              style={[styles.capIcon, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
        <Pressable
          style={[styles.rectangleParent, styles.groupLayout1]}
          onPress={() => navigation.navigate("IPhone13ProMax6")}
        >
          <View style={[styles.groupChild, styles.groupLayout1]} />
          <Text style={[styles.update, styles.updateClr]}>Update</Text>
        </Pressable>
        <View style={styles.confirmNewPasswordParent}>
          <Text style={[styles.confirmNewPassword, styles.newTypo]}>
            Confirm new password
          </Text>
          <View style={[styles.groupItem, styles.iphone13ChildLayout]} />
          <Text style={[styles.newPassword, styles.newTypo]}>New Password</Text>
          <View style={[styles.groupInner, styles.groupItemBorder]} />
          <View style={[styles.parent, styles.parentLayout]}>
            <Text style={[styles.text, styles.textLayout]}>.</Text>
            <Text style={[styles.text1, styles.textLayout]}>.</Text>
            <Text style={[styles.text2, styles.textLayout]}>.</Text>
            <Text style={[styles.text2, styles.textLayout]}>.</Text>
            <Text style={[styles.text4, styles.textLayout]}>.</Text>
            <Text style={[styles.text5, styles.text5Position]}>.</Text>
            <Text style={[styles.text6, styles.textLayout]}>.</Text>
            <Text style={[styles.text7, styles.text7Position]}>.</Text>
            <Text style={[styles.text8, styles.textLayout]}>.</Text>
            <Text style={[styles.text9, styles.text9Position]}>.</Text>
            <Text style={[styles.text10, styles.textLayout]}>.</Text>
            <Text style={[styles.text11, styles.textLayout]}>.</Text>
            <Text style={[styles.text12, styles.textLayout]}>.</Text>
            <Text style={[styles.text13, styles.textLayout]}>.</Text>
          </View>
          <View style={[styles.group, styles.parentLayout]}>
            <Text style={[styles.text, styles.textLayout]}>.</Text>
            <Text style={[styles.text1, styles.textLayout]}>.</Text>
            <Text style={[styles.text2, styles.textLayout]}>.</Text>
            <Text style={[styles.text2, styles.textLayout]}>.</Text>
            <Text style={[styles.text4, styles.textLayout]}>.</Text>
            <Text style={[styles.text5, styles.text5Position]}>.</Text>
            <Text style={[styles.text6, styles.textLayout]}>.</Text>
            <Text style={[styles.text7, styles.text7Position]}>.</Text>
            <Text style={[styles.text8, styles.textLayout]}>.</Text>
            <Text style={[styles.text9, styles.text9Position]}>.</Text>
            <Text style={[styles.text10, styles.textLayout]}>.</Text>
            <Text style={[styles.text11, styles.textLayout]}>.</Text>
            <Text style={[styles.text12, styles.textLayout]}>.</Text>
            <Text style={[styles.text13, styles.textLayout]}>.</Text>
          </View>
        </View>
        <Text style={[styles.resetPassword, styles.passwordTypo1]}>
          Reset Password
        </Text>
        <Text
          style={[styles.pleaseEnterYour, styles.passwordTypo1]}
        >{`please enter your new password and confirm
the password.`}</Text>
        <Image
          style={[styles.chevronLeftIcon, styles.chevronLayout]}
          contentFit="cover"
          source={require("../assets/chevronleft.png")}
        />
        <View style={[styles.chevronLeft, styles.chevronLayout]} />
      </View>
      <View style={[styles.iphone13ProMax5, styles.iphone13Layout1]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
        <View style={[styles.timeParent, styles.timeParentLayout]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection1.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <View style={[styles.battery, styles.batteryPosition]}>
            <View style={[styles.border, styles.borderBorder]} />
            <Image
              style={[styles.capIcon, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap1.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
        <Pressable
          style={[styles.rectangleGroup, styles.groupLayout1]}
          onPress={() => navigation.navigate("IPhone13ProMax5")}
        >
          <View style={[styles.rectangleView, styles.groupLayout1]} />
          <Text style={[styles.update, styles.updateClr]}>Update</Text>
        </Pressable>
        <View
          style={[styles.confirmNewPasswordGroup, styles.weHaveSentPosition]}
        >
          <Text style={[styles.confirmNewPassword, styles.newTypo]}>
            Confirm new password
          </Text>
          <View style={[styles.lineView, styles.iphone13ChildLayout]} />
          <Text style={[styles.newPassword, styles.newTypo]}>New Password</Text>
          <View style={[styles.groupChild1, styles.groupItemBorder]} />
        </View>
        <Text style={[styles.resetPassword, styles.passwordTypo1]}>
          Reset Password
        </Text>
        <Text
          style={[styles.pleaseEnterYour, styles.passwordTypo1]}
        >{`please enter your new password and confirm
the password.`}</Text>
        <Image
          style={[styles.chevronLeft, styles.chevronLayout]}
          contentFit="cover"
          source={require("../assets/chevronleft1.png")}
        />
      </View>
      <Pressable
        style={[styles.iphone13ProMax1, styles.iphone13Layout]}
        onPress={() => navigation.navigate("IPhone13ProMax9")}
      >
        <Image
          style={[styles.vectorIcon, styles.vectorIconLayout]}
          contentFit="cover"
          source={require("../assets/vector.png")}
        />
        <Text style={[styles.foodu, styles.fooduTypo]}>FOODU</Text>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
      </Pressable>
      <View style={[styles.iphone13ProMax2, styles.iphone13Layout]}>
        <View style={styles.iphone13ProMax2Inner}>
          <View style={styles.groupChildPosition}>
            <View style={styles.groupChildPosition}>
              <Image
                style={[styles.vectorIcon1, styles.vectorIconLayout]}
                contentFit="cover"
                source={require("../assets/vector1.png")}
              />
              <Text style={[styles.foodu1, styles.fooduTypo]}>FOODU</Text>
            </View>
          </View>
        </View>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
        <View style={[styles.timeParent, styles.timeParentLayout]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection2.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi2.png")}
          />
          <View style={[styles.battery, styles.batteryPosition]}>
            <View style={[styles.border, styles.borderBorder]} />
            <Image
              style={[styles.capIcon, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap2.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
        <View style={[styles.rectangleContainer, styles.groupLayout1]}>
          <View style={[styles.groupChild, styles.groupLayout1]} />
          <Text style={[styles.login, styles.loginTypo]}>Login</Text>
        </View>
        <View style={styles.groupParent}>
          <View style={styles.groupChildLayout1}>
            <View style={[styles.groupView, styles.groupChildLayout1]}>
              <View style={[styles.groupChild3, styles.groupChildShadowBox1]} />
              <Image
                style={styles.image3Icon}
                contentFit="cover"
                source={require("../assets/image-3.png")}
              />
              <Text style={[styles.facebook, styles.googleTypo]}>facebook</Text>
            </View>
          </View>
          <View style={[styles.image2Parent, styles.groupChildShadowBox1]}>
            <Image
              style={styles.image2IconLayout}
              contentFit="cover"
              source={require("../assets/image-2.png")}
            />
            <Text style={[styles.google, styles.googleTypo]}>Google</Text>
          </View>
        </View>
        <Text style={[styles.or, styles.orTypo]}>Or</Text>
        <Text style={[styles.password, styles.emailIdTypo]}>Password</Text>
        <View
          style={[styles.iphone13ProMax2Child, styles.iphone13ChildLayout]}
        />
        <Text style={[styles.emailId, styles.emailIdTypo]}>Email id</Text>
        <Text style={[styles.sattarmemn566gmailcom, styles.textContainerTypo]}>
          Sattarmemn566@gmail.com
        </Text>
        <View style={[styles.iphone13ProMax2Item, styles.groupItemBorder]} />
        <View style={[styles.container, styles.parentLayout]}>
          <Text style={[styles.text, styles.textLayout]}>.</Text>
          <Text style={[styles.text1, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text4, styles.textLayout]}>.</Text>
          <Text style={[styles.text5, styles.text5Position]}>.</Text>
          <Text style={[styles.text6, styles.textLayout]}>.</Text>
          <Text style={[styles.text7, styles.text7Position]}>.</Text>
          <Text style={[styles.text8, styles.textLayout]}>.</Text>
          <Text style={[styles.text9, styles.text9Position]}>.</Text>
          <Text style={[styles.text10, styles.textLayout]}>.</Text>
          <Text style={[styles.text11, styles.textLayout]}>.</Text>
          <Text style={[styles.text12, styles.textLayout]}>.</Text>
          <Text style={[styles.text13, styles.textLayout]}>.</Text>
        </View>
        <Pressable
          style={[styles.forgotPassword, styles.pressablePosition]}
          onPress={() => navigation.navigate("IPhone13ProMax8")}
        >
          <Text style={[styles.forgotPassword1, styles.haveTypo]}>
            forgot password?
          </Text>
        </Pressable>
        <Text style={[styles.dontHaveAnContainer, styles.haveTypo]}>
          <Text style={styles.dontHaveAn}>dont have an account?</Text>
          <Text style={styles.registerNow}>{`register now `}</Text>
        </Text>
      </View>
      <View style={[styles.iphone13ProMax3, styles.iphone13Layout1]}>
        <View style={styles.iphone13ProMax2Inner}>
          <View style={styles.groupChildPosition}>
            <View style={styles.groupChildPosition}>
              <Image
                style={[styles.vectorIcon1, styles.vectorIconLayout]}
                contentFit="cover"
                source={require("../assets/vector2.png")}
              />
              <Text style={[styles.foodu1, styles.fooduTypo]}>FOODU</Text>
            </View>
          </View>
        </View>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
        <View style={[styles.timeParent, styles.timeParentLayout]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection3.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi3.png")}
          />
          <View style={[styles.battery, styles.batteryPosition]}>
            <View style={[styles.border, styles.borderBorder]} />
            <Image
              style={[styles.capIcon, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap3.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
        <View style={[styles.rectangleContainer, styles.groupLayout1]}>
          <View style={[styles.rectangleView, styles.groupLayout1]} />
          <Text style={[styles.login1, styles.loginTypo]}>Login</Text>
        </View>
        <View style={styles.groupParent}>
          <View style={styles.groupChildLayout1}>
            <View style={[styles.groupView, styles.groupChildLayout1]}>
              <View style={[styles.groupChild5, styles.groupChildShadowBox1]} />
              <Image
                style={styles.image3Icon}
                contentFit="cover"
                source={require("../assets/image-31.png")}
              />
              <Text style={[styles.facebook, styles.googleTypo]}>facebook</Text>
            </View>
          </View>
          <View style={[styles.rectangleParent3, styles.groupChildLayout1]}>
            <View style={[styles.groupChild6, styles.groupChildShadowBox1]} />
            <Image
              style={[styles.image2Icon1, styles.image2IconLayout]}
              contentFit="cover"
              source={require("../assets/image-21.png")}
            />
            <Text style={[styles.google1, styles.googleTypo]}>Google</Text>
          </View>
        </View>
        <Text style={[styles.or, styles.orTypo]}>Or</Text>
        <Text style={[styles.password, styles.emailIdTypo]}>Password</Text>
        <View
          style={[styles.iphone13ProMax3Child, styles.iphone13ChildLayout]}
        />
        <Text style={[styles.emailId, styles.emailIdTypo]}>Email id</Text>
        <View style={[styles.iphone13ProMax3Item, styles.groupItemBorder]} />
        <Pressable
          style={[styles.forgotPassword, styles.pressablePosition]}
          onPress={() => navigation.navigate("IPhone13ProMax7")}
        >
          <Text style={[styles.forgotPassword1, styles.haveTypo]}>
            forgot password?
          </Text>
        </Pressable>
        <Text style={[styles.dontHaveAnContainer, styles.haveTypo]}>
          <Text style={styles.dontHaveAn}>dont have an account?</Text>
          <Text style={styles.registerNow}>{`register now `}</Text>
        </Text>
      </View>
      <View style={[styles.iphone13ProMax4, styles.iphone13Layout]}>
        <Text style={[styles.checkYouEmail, styles.loginTypo]}>
          Check you Email
        </Text>
        <Text
          style={[styles.weHaveSent, styles.haveTypo]}
        >{`we have sent you a reset password link 
      on ypur registered email address`}</Text>
        <Pressable
          style={[styles.iphone13ProMax4Inner, styles.groupLayout]}
          onPress={() => navigation.navigate("IPhone13ProMax4")}
        >
          <View style={[styles.groupWrapper2, styles.groupLayout]}>
            <View style={[styles.groupWrapper2, styles.groupLayout]}>
              <View style={[styles.groupChild7, styles.groupLayout]} />
              <Text style={[styles.goToEmail, styles.updateClr]}>
                Go to Email
              </Text>
            </View>
          </View>
        </Pressable>
        <Image
          style={styles.sendingEmailAtRocketSpeed}
          contentFit="cover"
          source={require("../assets/sending-email-at-rocket-speed.png")}
        />
        <View style={[styles.timeParent2, styles.timeParentPosition]}>
          <Text style={[styles.time4, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection4.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi4.png")}
          />
          <View style={[styles.battery4, styles.batteryPosition]}>
            <View style={[styles.border4, styles.borderBorder]} />
            <Image
              style={[styles.capIcon4, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap4.png")}
            />
            <View style={[styles.capacity4, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.iphone13ProMax9, styles.iphone13Position1]}>
        <Image
          style={styles.vectorIcon3}
          contentFit="cover"
          source={require("../assets/vector3.png")}
        />
        <Text
          style={[styles.enter4Digit, styles.text42Typo]}
        >{`Enter 4 digit code sent
                 To you`}</Text>
        <View style={[styles.groupParent1, styles.groupChildShadowBox1]}>
          <View style={styles.rectangleParentLayout}>
            <View style={styles.groupChildShadowBox} />
            <Text style={[styles.text42, styles.text42Typo]}>4</Text>
          </View>
          <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
            <View style={styles.groupChildShadowBox} />
            <Text style={[styles.text42, styles.text42Typo]}>9</Text>
          </View>
          <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
            <View style={styles.groupChildShadowBox} />
            <Text style={[styles.text42, styles.text42Typo]}>6</Text>
          </View>
          <View style={[styles.rectangleParent6, styles.rectangleParentLayout]}>
            <View style={styles.groupChildShadowBox} />
            <Text style={[styles.text42, styles.text42Typo]}>7</Text>
          </View>
        </View>
        <Pressable
          style={styles.iphone13ProMax9Child}
          onPress={() => navigation.navigate("IPhone13ProMax2")}
        />
        <Text style={[styles.verify, styles.updateClr]}>Verify</Text>
        <Text style={[styles.didntReceiveA, styles.orTypo]}>
          Didn’t receive a verification code?
        </Text>
        <Text style={[styles.resendCode, styles.orTypo]}>
          Resend code | Change Number
        </Text>
        <View style={styles.timeParent3}>
          <Text style={[styles.time4, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection5.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi5.png")}
          />
          <View style={[styles.battery4, styles.batteryPosition]}>
            <View style={[styles.border4, styles.borderBorder]} />
            <Image
              style={[styles.capIcon4, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap5.png")}
            />
            <View style={[styles.capacity4, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.iphone13ProMax7, styles.iphone13Position]}>
        <Image
          style={styles.vectorIcon4}
          contentFit="cover"
          source={require("../assets/vector4.png")}
        />
        <Text style={[styles.registerToFoodu, styles.registerTypo]}>
          Register to foodu
        </Text>
        <View style={styles.frameParent}>
          <View style={styles.fullNameParent}>
            <Text style={[styles.fullName, styles.emailTypo]}>Full Name</Text>
            <Text style={[styles.email, styles.emailTypo]}>Email</Text>
            <Text style={[styles.email, styles.emailTypo]}>Mobile Number</Text>
            <Text style={[styles.email, styles.emailTypo]}>Password</Text>
            <Text style={[styles.email, styles.emailTypo]}>
              Confirm Password
            </Text>
          </View>
          <View style={styles.lineParent}>
            <View style={styles.frameLayout} />
            <View style={[styles.frameItem, styles.frameLayout]} />
            <View style={[styles.frameItem, styles.frameLayout]} />
            <View style={[styles.frameItem, styles.frameLayout]} />
            <View style={[styles.frameItem, styles.frameLayout]} />
          </View>
        </View>
        <Pressable
          style={[styles.groupPressable, styles.pressablePosition]}
          onPress={() => navigation.navigate("IPhone13ProMax3")}
        >
          <View style={[styles.rectangleView, styles.groupLayout1]} />
          <Text style={[styles.update, styles.updateClr]}>Register</Text>
        </Pressable>
        <Text
          style={[styles.byRegisteringYouContainer, styles.textContainerTypo]}
        >
          <Text style={styles.byRegisteringYou}>
            By registering you agree to
          </Text>
          <Text style={styles.registerNow}>{` Terms & conditions`}</Text>
        </Text>
        <Text
          style={[styles.andPrivacyPolicyContainer, styles.textContainerTypo]}
        >
          <Text style={styles.byRegisteringYou}> and</Text>
          <Text style={styles.registerNow}> privacy Policy</Text>
          <Text style={styles.byRegisteringYou}> of the foodu</Text>
        </Text>
        <View style={[styles.timeParent4, styles.timeParentPosition]}>
          <Text style={[styles.time4, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection6.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi6.png")}
          />
          <View style={[styles.battery4, styles.batteryPosition]}>
            <View style={[styles.border4, styles.borderBorder]} />
            <Image
              style={[styles.capIcon4, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap6.png")}
            />
            <View style={[styles.capacity4, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.iphone13ProMax8, styles.iphone13Position]}>
        <Image
          style={styles.vectorIcon4}
          contentFit="cover"
          source={require("../assets/vector5.png")}
        />
        <Text style={[styles.registerToFoodu1, styles.registerTypo]}>
          Register to foodu
        </Text>
        <Text style={[styles.fullName1, styles.passwordTypo]}>Full Name</Text>
        <Text style={[styles.manthan29181, styles.passwordTypo]}>
          Manthan 2918
        </Text>
        <Text style={[styles.email1, styles.passwordTypo]}>Email</Text>
        <Text style={[styles.mobileNumber1, styles.passwordTypo]}>
          Mobile Number
        </Text>
        <Text style={[styles.password3, styles.passwordTypo]}>Password</Text>
        <Text style={[styles.confirmPassword1, styles.passwordTypo]}>
          Confirm Password
        </Text>
        <View
          style={[styles.iphone13ProMax8Child, styles.iphone13ChildPosition]}
        />
        <View
          style={[styles.iphone13ProMax8Item, styles.iphone13ChildPosition]}
        />
        <View
          style={[styles.iphone13ProMax8Inner, styles.iphone13ChildPosition]}
        />
        <View
          style={[styles.iphone13ProMax8Child1, styles.iphone13ChildPosition]}
        />
        <View
          style={[styles.iphone13ProMax8Child2, styles.iphone13ChildPosition]}
        />
        <Pressable
          style={[styles.rectanglePressable, styles.pressablePosition]}
          onPress={() => navigation.navigate("IPhone13ProMax1")}
        />
        <Text style={[styles.register1, styles.updateClr]}>Register</Text>
        <Text
          style={[styles.byRegisteringYouContainer, styles.textContainerTypo]}
        >
          <Text style={styles.byRegisteringYou}>
            By registering you agree to
          </Text>
          <Text style={styles.registerNow}>{` Terms & conditions`}</Text>
        </Text>
        <Text
          style={[styles.andPrivacyPolicyContainer, styles.textContainerTypo]}
        >
          <Text style={styles.byRegisteringYou}> and</Text>
          <Text style={styles.registerNow}> privacy Policy</Text>
          <Text style={styles.byRegisteringYou}> of the foodu</Text>
        </Text>
        <View style={[styles.timeParent5, styles.timeParentLayout]}>
          <Text style={[styles.time4, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection7.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi7.png")}
          />
          <View style={[styles.battery4, styles.batteryPosition]}>
            <View style={[styles.border7, styles.borderBorder]} />
            <Image
              style={[styles.capIcon7, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap7.png")}
            />
            <View style={[styles.capacity7, styles.capacityPosition]} />
          </View>
        </View>
        <View style={[styles.parent1, styles.parentLayout]}>
          <Text style={[styles.text, styles.textLayout]}>.</Text>
          <Text style={[styles.text1, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text4, styles.textLayout]}>.</Text>
          <Text style={[styles.text5, styles.text5Position]}>.</Text>
          <Text style={[styles.text6, styles.textLayout]}>.</Text>
          <Text style={[styles.text7, styles.text7Position]}>.</Text>
          <Text style={[styles.text8, styles.textLayout]}>.</Text>
          <Text style={[styles.text9, styles.text9Position]}>.</Text>
          <Text style={[styles.text10, styles.textLayout]}>.</Text>
          <Text style={[styles.text11, styles.textLayout]}>.</Text>
          <Text style={[styles.text12, styles.textLayout]}>.</Text>
          <Text style={[styles.text13, styles.textLayout]}>.</Text>
        </View>
        <View style={[styles.parent2, styles.parentLayout]}>
          <Text style={[styles.text, styles.textLayout]}>.</Text>
          <Text style={[styles.text1, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text2, styles.textLayout]}>.</Text>
          <Text style={[styles.text4, styles.textLayout]}>.</Text>
          <Text style={[styles.text5, styles.text5Position]}>.</Text>
          <Text style={[styles.text6, styles.textLayout]}>.</Text>
          <Text style={[styles.text7, styles.text7Position]}>.</Text>
          <Text style={[styles.text8, styles.textLayout]}>.</Text>
          <Text style={[styles.text9, styles.text9Position]}>.</Text>
          <Text style={[styles.text10, styles.textLayout]}>.</Text>
          <Text style={[styles.text11, styles.textLayout]}>.</Text>
          <Text style={[styles.text12, styles.textLayout]}>.</Text>
          <Text style={[styles.text13, styles.textLayout]}>.</Text>
        </View>
      </View>
      <View style={[styles.iphone13ProMax10, styles.iphone13Position1]}>
        <Image
          style={[styles.vectorIcon6, styles.vectorIcon6Position]}
          contentFit="cover"
          source={require("../assets/vector6.png")}
        />
        <Text style={[styles.forgotPassword4, styles.vectorIcon6Position]}>
          Forgot Password
        </Text>
        <Text
          style={[styles.pleaseEnterYour2, styles.pleaseEnterYour2Typo]}
        >{`Please enter your registered email or mobile
to reset your Password.`}</Text>
        <Text style={[styles.emailmobileNumber, styles.pleaseEnterYour2Typo]}>
          Email/Mobile number
        </Text>
        <View style={styles.iphone13ProMax10Child} />
        <Pressable
          style={styles.rectangleParent9}
          onPress={() => navigation.navigate("IPhone13ProMax")}
        >
          <View style={[styles.groupChild13, styles.groupChildPosition]} />
          <Text style={[styles.recoverPassword, styles.updateClr]}>
            Recover Password
          </Text>
        </Pressable>
        <View style={[styles.timeParent6, styles.timeParentLayout]}>
          <Text style={[styles.time8, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection8.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi8.png")}
          />
          <View style={[styles.battery4, styles.batteryPosition]}>
            <View style={[styles.border8, styles.borderBorder]} />
            <Image
              style={[styles.capIcon8, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap8.png")}
            />
            <View style={[styles.capacity8, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.iphone13ProMax11, styles.iphone13Position1]}>
        <Image
          style={[styles.vectorIcon6, styles.vectorIcon6Position]}
          contentFit="cover"
          source={require("../assets/vector7.png")}
        />
        <Text style={[styles.forgotPassword4, styles.vectorIcon6Position]}>
          Forgot Password
        </Text>
        <Text
          style={[styles.pleaseEnterYour2, styles.pleaseEnterYour2Typo]}
        >{`Please enter your registered email or mobile
to reset your Password.`}</Text>
        <Text style={[styles.emailmobileNumber, styles.pleaseEnterYour2Typo]}>
          Email/Mobile number
        </Text>
        <View style={styles.iphone13ProMax10Child} />
        <View style={styles.rectangleParent9}>
          <View style={[styles.groupChild14, styles.groupChildPosition]} />
          <Text style={[styles.recoverPassword, styles.updateClr]}>
            Recover Password
          </Text>
        </View>
        <View style={[styles.timeParent7, styles.timeParentLayout]}>
          <Text style={[styles.time8, styles.timeTypo]}>9:41</Text>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection9.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi9.png")}
          />
          <View style={[styles.battery9, styles.batteryPosition]}>
            <View style={[styles.border9, styles.borderBorder]} />
            <Image
              style={[styles.capIcon9, styles.capIconPosition]}
              contentFit="cover"
              source={require("../assets/cap9.png")}
            />
            <View style={[styles.capacity9, styles.capacityPosition]} />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iphone13Layout1: {
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    width: "22.06%",
    height: "30.57%",
    position: "absolute",
  },
  timeParentLayout: {
    height: "2.48%",
    position: "absolute",
  },
  timeTypo: {
    textAlign: "center",
    letterSpacing: 0,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  batteryPosition: {
    bottom: "16.96%",
    top: "33.91%",
    height: "49.13%",
    right: "0%",
    position: "absolute",
  },
  borderBorder: {
    opacity: 0.35,
    borderWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    borderRadius: 3,
    bottom: "0%",
    height: "100%",
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  capIconPosition: {
    opacity: 0.4,
    bottom: "31.86%",
    top: "32.74%",
    height: "35.4%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  capacityPosition: {
    backgroundColor: Color.colorBlack,
    borderRadius: 1,
    bottom: "17.7%",
    top: "17.7%",
    height: "64.6%",
    position: "absolute",
  },
  groupLayout1: {
    height: 50,
    width: 343,
  },
  updateClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  newTypo: {
    color: Color.colorGray_600,
    textTransform: "capitalize",
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  iphone13ChildLayout: {
    height: 1,
    borderTopWidth: 1,
    borderColor: Color.colorGray_500,
    width: 339,
    borderStyle: "solid",
    position: "absolute",
  },
  groupItemBorder: {
    borderColor: Color.colorGray_700,
    height: 1,
    borderTopWidth: 1,
    width: 339,
    borderStyle: "solid",
    position: "absolute",
  },
  parentLayout: {
    height: 48,
    width: 117,
    position: "absolute",
  },
  textLayout: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    top: 0,
  },
  text5Position: {
    left: 34,
    position: "absolute",
  },
  text7Position: {
    left: 51,
    textAlign: "left",
    position: "absolute",
  },
  text9Position: {
    left: 67,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  passwordTypo1: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  chevronLayout: {
    height: 38,
    width: 41,
    overflow: "hidden",
    position: "absolute",
  },
  weHaveSentPosition: {
    left: 53,
    position: "absolute",
  },
  iphone13Layout: {
    height: 926,
    width: 437,
    top: 0,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  fooduTypo: {
    fontFamily: FontFamily.judsonBold,
    fontSize: FontSize.size_21xl,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  loginTypo: {
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  groupChildLayout1: {
    height: 57,
    width: 161,
  },
  groupChildShadowBox1: {
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  googleTypo: {
    color: Color.colorGray_400,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
  },
  orTypo: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  emailIdTypo: {
    textTransform: "uppercase",
    color: Color.colorGray_600,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  textContainerTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  pressablePosition: {
    top: 671,
    position: "absolute",
  },
  haveTypo: {
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  image2IconLayout: {
    height: 41,
    width: 38,
  },
  groupLayout: {
    width: 293,
    height: 50,
    position: "absolute",
  },
  timeParentPosition: {
    right: "2.58%",
    width: "97.42%",
    left: "0%",
    height: "2.48%",
    position: "absolute",
  },
  iphone13Position1: {
    top: 2104,
    height: 926,
    width: 437,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  text42Typo: {
    fontSize: FontSize.size_9xl,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParentLayout: {
    height: 54,
    width: 60,
  },
  iphone13Position: {
    top: 1021,
    height: 926,
    width: 437,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  registerTypo: {
    top: "14.55%",
    left: "8.03%",
    fontSize: FontSize.size_9xl,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  emailTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  frameLayout: {
    width: 319,
    borderColor: Color.colorGray_1400,
    height: 1,
    borderTopWidth: 1,
    borderStyle: "solid",
  },
  passwordTypo: {
    left: "9.67%",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  iphone13ChildPosition: {
    left: "9.56%",
    right: "15.8%",
    width: "74.64%",
    height: "0.11%",
    borderColor: Color.colorGray_1400,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  vectorIcon6Position: {
    left: "8.83%",
    position: "absolute",
  },
  pleaseEnterYour2Typo: {
    color: Color.colorGray_1700,
    left: "8.83%",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    position: "absolute",
  },
  groupChildPosition: {
    bottom: "0%",
    height: "100%",
    right: "0%",
    left: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  unionIcon: {
    width: 0,
    height: 0,
    left: 0,
    top: 0,
    position: "absolute",
  },
  time: {
    width: "14.14%",
  },
  cellularConnectionIcon: {
    width: 19,
    height: 11,
  },
  wifiIcon: {
    width: 17,
    height: 11,
  },
  border: {
    width: "90.3%",
    right: "9.7%",
  },
  capIcon: {
    width: "5.6%",
    left: "94.4%",
    right: "0%",
  },
  capacity: {
    width: "73.88%",
    right: "17.91%",
    left: "8.21%",
  },
  battery: {
    width: "6.37%",
    left: "93.63%",
  },
  timeParent: {
    width: "96.25%",
    top: "0.86%",
    right: "2.81%",
    bottom: "96.65%",
    left: "0.94%",
  },
  groupChild: {
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
    position: "absolute",
  },
  update: {
    left: 134,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
    top: 10,
  },
  rectangleParent: {
    top: 509,
    left: 49,
    width: 343,
    position: "absolute",
  },
  confirmNewPassword: {
    top: 87,
    left: 0,
  },
  groupItem: {
    top: 145,
    left: 1,
  },
  newPassword: {
    left: 1,
    top: 0,
  },
  groupInner: {
    top: 58,
    left: 0,
  },
  text: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 0,
    position: "absolute",
  },
  text1: {
    left: 8,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text2: {
    left: 17,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text4: {
    left: 25,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text5: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    top: 0,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text6: {
    left: 42,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text7: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    top: 0,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text8: {
    left: 59,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text9: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    top: 0,
    textAlign: "left",
  },
  text10: {
    left: 76,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text11: {
    left: 84,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text12: {
    left: 93,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text13: {
    left: 101,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  parent: {
    left: 0,
    top: 0,
  },
  group: {
    left: 1,
    top: 87,
  },
  confirmNewPasswordParent: {
    height: 146,
    width: 339,
    left: 53,
    top: 302,
    position: "absolute",
  },
  resetPassword: {
    top: 142,
    fontSize: FontSize.size_6xl,
    color: Color.colorGray_100,
    left: 51,
    textAlign: "left",
    position: "absolute",
  },
  pleaseEnterYour: {
    top: 199,
    left: 50,
    color: Color.colorGray_200,
    textAlign: "left",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  chevronLeftIcon: {
    top: 68,
    left: 37,
  },
  chevronLeft: {
    top: 75,
    left: 36,
  },
  iphone13ProMax6: {
    right: "51.8%",
    left: "26.14%",
    bottom: "35.73%",
    top: "33.7%",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    width: "22.06%",
    height: "30.57%",
  },
  rectangleView: {
    backgroundColor: Color.colorGainsboro_100,
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
    position: "absolute",
  },
  rectangleGroup: {
    top: 495,
    left: 49,
    width: 343,
    position: "absolute",
  },
  lineView: {
    top: 131,
    left: 3,
  },
  groupChild1: {
    top: 46,
    left: 0,
  },
  confirmNewPasswordGroup: {
    width: 341,
    height: 131,
    top: 302,
    left: 53,
  },
  iphone13ProMax5: {
    right: "77.94%",
    left: "0%",
    bottom: "35.73%",
    top: "33.7%",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    width: "22.06%",
    height: "30.57%",
  },
  vectorIcon: {
    height: "15.25%",
    width: "32.29%",
    top: "40.25%",
    right: "33.87%",
    bottom: "44.5%",
    left: "33.84%",
    position: "absolute",
  },
  foodu: {
    top: "57.83%",
    left: "36.09%",
    width: "28.04%",
  },
  iphone13ProMax1: {
    left: 0,
  },
  vectorIcon1: {
    height: "60.05%",
    width: "99.51%",
    bottom: "39.95%",
    left: "0.49%",
    right: "0%",
    top: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
  },
  foodu1: {
    top: "71.81%",
    left: "0%",
    width: "100%",
  },
  iphone13ProMax2Inner: {
    height: "18%",
    top: "12.7%",
    right: "36.93%",
    bottom: "69.3%",
    left: "35.03%",
    width: "28.04%",
    position: "absolute",
  },
  login: {
    top: 7,
    left: 138,
    fontSize: FontSize.size_5xl,
    color: Color.colorWhite,
  },
  rectangleContainer: {
    top: 740,
    left: 43,
    position: "absolute",
  },
  groupChild3: {
    elevation: 17,
    shadowRadius: 17,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    height: 57,
    width: 161,
    left: 0,
    top: 0,
    position: "absolute",
  },
  image3Icon: {
    top: 13,
    left: 26,
    borderRadius: Border.br_7xs,
    width: 32,
    height: 32,
    position: "absolute",
  },
  facebook: {
    left: 69,
    top: 20,
    color: Color.colorGray_400,
    position: "absolute",
  },
  groupView: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  google: {
    marginLeft: 5,
  },
  image2Parent: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_7xs,
    marginLeft: 41,
    alignItems: "center",
    elevation: 17,
    shadowRadius: 17,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    flexDirection: "row",
  },
  groupParent: {
    top: 344,
    left: 29,
    flexDirection: "row",
    position: "absolute",
  },
  or: {
    top: 429,
    left: 201,
    color: Color.colorBlack,
  },
  password: {
    top: 594,
    left: 42,
  },
  iphone13ProMax2Child: {
    top: 653,
    left: 41,
  },
  emailId: {
    top: 507,
    left: 43,
  },
  sattarmemn566gmailcom: {
    top: 534,
    color: Color.colorGray_300,
    left: 43,
    textAlign: "left",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  iphone13ProMax2Item: {
    top: 568,
    left: 42,
  },
  container: {
    top: 600,
    left: 42,
  },
  forgotPassword1: {
    textTransform: "lowercase",
    color: Color.colorCrimson,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  forgotPassword: {
    left: 251,
  },
  dontHaveAn: {
    color: Color.colorGray_800,
  },
  registerNow: {
    color: Color.colorCrimson,
  },
  dontHaveAnContainer: {
    top: 829,
    left: 67,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    textTransform: "capitalize",
    fontSize: FontSize.size_base,
  },
  iphone13ProMax2: {
    left: 518,
  },
  login1: {
    top: 5,
    left: 138,
    fontSize: FontSize.size_5xl,
    color: Color.colorWhite,
  },
  groupChild5: {
    elevation: 17,
    shadowRadius: 17,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    height: 57,
    width: 161,
    left: 0,
    top: 0,
    position: "absolute",
  },
  groupChild6: {
    elevation: 17,
    shadowRadius: 17,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    height: 57,
    width: 161,
    left: 0,
    top: 0,
    position: "absolute",
  },
  image2Icon1: {
    top: 9,
    left: 34,
    position: "absolute",
  },
  google1: {
    left: 77,
    top: 20,
    color: Color.colorGray_400,
    position: "absolute",
  },
  rectangleParent3: {
    marginLeft: 48,
  },
  iphone13ProMax3Child: {
    top: 639,
    left: 41,
  },
  iphone13ProMax3Item: {
    top: 554,
    left: 41,
  },
  iphone13ProMax3: {
    top: "0.04%",
    right: "26.07%",
    bottom: "69.4%",
    left: "51.87%",
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
    width: "22.06%",
    height: "30.57%",
  },
  checkYouEmail: {
    top: 475,
    left: 113,
    color: Color.colorBlack,
  },
  weHaveSent: {
    top: 529,
    color: Color.colorGray_900,
    left: 53,
    position: "absolute",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  groupChild7: {
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  goToEmail: {
    left: 89,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
    top: 10,
  },
  groupWrapper2: {
    left: 0,
    top: 0,
  },
  iphone13ProMax4Inner: {
    top: 630,
    left: 68,
  },
  sendingEmailAtRocketSpeed: {
    top: 63,
    left: 16,
    width: 395,
    height: 448,
    position: "absolute",
  },
  time4: {
    width: "14.13%",
  },
  border4: {
    width: "90.41%",
    right: "9.59%",
  },
  capIcon4: {
    width: "5.54%",
    left: "94.46%",
    right: "0%",
  },
  capacity4: {
    width: "74.17%",
    right: "17.71%",
    left: "8.12%",
  },
  battery4: {
    width: "6.36%",
    left: "93.64%",
  },
  timeParent2: {
    top: "0.97%",
    bottom: "96.54%",
  },
  iphone13ProMax4: {
    left: 1536,
  },
  vectorIcon3: {
    top: "7.88%",
    right: "84.43%",
    bottom: "89.87%",
    left: "12.3%",
    width: "3.27%",
    height: "2.25%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  enter4Digit: {
    top: "15.01%",
    width: "74.3%",
    left: "12.3%",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    color: Color.colorBlack,
  },
  groupChildShadowBox: {
    elevation: 12,
    shadowRadius: 12,
    backgroundColor: Color.colorGray_1000,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    bottom: "0%",
    height: "100%",
    right: "0%",
    left: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  text42: {
    top: "11.42%",
    left: "34.12%",
    color: Color.colorGray_1100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  rectangleParent6: {
    marginLeft: 35,
  },
  groupParent1: {
    top: 297,
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    flexDirection: "row",
    left: 42,
    position: "absolute",
  },
  iphone13ProMax9Child: {
    top: 425,
    width: 344,
    height: 56,
    left: 42,
    backgroundColor: Color.colorCrimson,
    position: "absolute",
  },
  verify: {
    top: 437,
    left: 182,
    fontSize: FontSize.size_3xl,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  didntReceiveA: {
    top: 520,
    left: 90,
    color: Color.colorGray_1500,
  },
  resendCode: {
    top: 551,
    left: 100,
    color: Color.colorCrimson,
  },
  timeParent3: {
    top: "1.04%",
    right: "2.54%",
    bottom: "96.48%",
    left: "0.05%",
    width: "97.42%",
    height: "2.48%",
    position: "absolute",
  },
  iphone13ProMax9: {
    left: 0,
  },
  vectorIcon4: {
    top: "8.42%",
    right: "88.7%",
    bottom: "89.33%",
    left: "8.03%",
    width: "3.27%",
    height: "2.25%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  registerToFoodu: {
    width: "57.01%",
  },
  fullName: {
    color: Color.colorGray_1300,
    textAlign: "left",
    fontSize: FontSize.size_sm,
  },
  email: {
    marginTop: 58,
    color: Color.colorGray_1300,
    textAlign: "left",
    fontSize: FontSize.size_sm,
  },
  fullNameParent: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  frameItem: {
    marginTop: 79,
  },
  lineParent: {
    top: 43,
    alignItems: "center",
    left: 0,
    position: "absolute",
  },
  frameParent: {
    top: 219,
    width: 318,
    height: 359,
    left: 41,
    position: "absolute",
  },
  groupPressable: {
    left: 41,
    height: 50,
    width: 343,
  },
  byRegisteringYou: {
    color: Color.colorGray_1500,
  },
  byRegisteringYouContainer: {
    top: 764,
    left: 61,
    fontSize: FontSize.size_smi,
    textAlign: "left",
    position: "absolute",
  },
  andPrivacyPolicyContainer: {
    top: 794,
    left: 64,
    fontSize: FontSize.size_smi,
    textAlign: "left",
    position: "absolute",
  },
  timeParent4: {
    top: "0.82%",
    bottom: "96.7%",
  },
  iphone13ProMax7: {
    left: 1027,
  },
  registerToFoodu1: {
    width: "59.57%",
  },
  fullName1: {
    width: "16.58%",
    top: "23.69%",
    color: Color.colorGray_1300,
  },
  manthan29181: {
    width: "29.68%",
    top: "26.1%",
    color: Color.colorGray_1200,
  },
  email1: {
    width: "9.35%",
    top: "32.22%",
    color: Color.colorGray_1300,
  },
  mobileNumber1: {
    width: "25.47%",
    top: "40.76%",
    color: Color.colorGray_1300,
  },
  password3: {
    width: "16.35%",
    top: "49.29%",
    color: Color.colorGray_1300,
  },
  confirmPassword1: {
    width: "30.6%",
    top: "57.82%",
    color: Color.colorGray_1300,
  },
  iphone13ProMax8Child: {
    top: "28.8%",
    bottom: "71.09%",
  },
  iphone13ProMax8Item: {
    top: "37.41%",
    bottom: "62.48%",
  },
  iphone13ProMax8Inner: {
    top: "46.59%",
    bottom: "53.3%",
  },
  iphone13ProMax8Child1: {
    top: "55.77%",
    bottom: "44.13%",
  },
  iphone13ProMax8Child2: {
    top: "64.95%",
    bottom: "34.95%",
  },
  rectanglePressable: {
    left: 41,
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_8xs,
    height: 50,
    width: 343,
  },
  register1: {
    top: 681,
    left: 175,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
  },
  border7: {
    width: "90.51%",
    right: "9.49%",
  },
  capIcon7: {
    width: "5.47%",
    left: "94.53%",
    right: "0%",
  },
  capacity7: {
    width: "74.09%",
    right: "17.52%",
    left: "8.39%",
  },
  timeParent5: {
    width: "98.58%",
    top: "0.78%",
    right: "2.65%",
    bottom: "96.74%",
    left: "-1.23%",
  },
  parent1: {
    top: 467,
    left: 46,
  },
  parent2: {
    top: 550,
    left: 48,
  },
  iphone13ProMax8: {
    left: 1545,
  },
  vectorIcon6: {
    height: "2.34%",
    width: "3.18%",
    top: "9.4%",
    right: "87.99%",
    bottom: "88.26%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  forgotPassword4: {
    width: "52.09%",
    top: "15.53%",
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_1600,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
  },
  pleaseEnterYour2: {
    top: "21.61%",
    width: "74.3%",
    fontSize: FontSize.size_sm,
  },
  emailmobileNumber: {
    width: "33.87%",
    top: "33.02%",
    fontSize: FontSize.size_smi,
  },
  iphone13ProMax10Child: {
    width: "74.89%",
    top: "38.62%",
    right: "16.76%",
    bottom: "61.27%",
    left: "8.35%",
    borderColor: Color.colorGray_1800,
    height: "0.11%",
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  groupChild13: {
    backgroundColor: Color.colorGainsboro_200,
    borderRadius: Border.br_8xs,
  },
  recoverPassword: {
    width: "40.25%",
    top: "29.63%",
    left: "29.87%",
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
  },
  rectangleParent9: {
    height: "5.54%",
    width: "76.01%",
    top: "45.55%",
    right: "13.31%",
    bottom: "48.91%",
    left: "10.68%",
    position: "absolute",
  },
  time8: {
    width: "14.12%",
  },
  border8: {
    width: "90.58%",
    right: "9.42%",
  },
  capIcon8: {
    width: "5.43%",
    left: "94.57%",
    right: "0%",
  },
  capacity8: {
    width: "73.91%",
    right: "17.75%",
    left: "8.33%",
  },
  timeParent6: {
    width: "99.29%",
    top: "0.99%",
    right: "1.92%",
    bottom: "96.52%",
    left: "-1.21%",
  },
  iphone13ProMax10: {
    left: 808,
  },
  groupChild14: {
    backgroundColor: Color.colorCrimson,
    borderRadius: Border.br_8xs,
  },
  border9: {
    width: "90.74%",
    right: "9.26%",
  },
  capIcon9: {
    width: "5.56%",
    right: "-0.37%",
    left: "94.81%",
  },
  capacity9: {
    width: "74.07%",
    right: "17.78%",
    left: "8.15%",
  },
  battery9: {
    width: "6.35%",
    left: "93.65%",
  },
  timeParent7: {
    width: "97.19%",
    top: "0.89%",
    right: "2.01%",
    bottom: "96.63%",
    left: "0.8%",
  },
  iphone13ProMax11: {
    left: 1536,
  },
  manthan2918: {
    flex: 1,
    height: 3030,
    width: "100%",
  },
});

export default Manthan;
