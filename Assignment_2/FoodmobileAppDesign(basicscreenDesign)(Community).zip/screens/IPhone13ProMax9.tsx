import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import DataContainer from "../components/DataContainer";
import GroupComponent1 from "../components/GroupComponent1";
import GoogleContainer from "../components/GoogleContainer";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const IPhone13ProMax9 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax2}>
      <DataContainer dimensionsCode={require("../assets/vector1.png")} />
      <Image
        style={[styles.unionIcon, styles.unionIconPosition]}
        contentFit="cover"
        source={require("../assets/union.png")}
      />
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection2.png")}
        wifi={require("../assets/wifi2.png")}
        cap={require("../assets/cap2.png")}
        groupViewPosition="absolute"
        groupViewWidth="96.25%"
        groupViewHeight="2.48%"
        groupViewTop="0.86%"
        groupViewRight="2.81%"
        groupViewBottom="96.65%"
        groupViewLeft="0.94%"
        timeWidth="14.14%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.37%"
        batteryLeft="93.63%"
        borderWidth="90.3%"
        borderRight="9.7%"
        capIconWidth="5.6%"
        capIconLeft="94.4%"
        capIconRight="0%"
        capacityWidth="73.88%"
        capacityRight="17.91%"
        capacityLeft="8.21%"
      />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={styles.login}>Login</Text>
      </View>
      <GoogleContainer />
      <Text style={styles.or}>Or</Text>
      <Text style={[styles.password, styles.emailIdTypo]}>Password</Text>
      <View style={[styles.iphone13ProMax2Child, styles.iphone13Layout]} />
      <Text style={[styles.emailId, styles.emailIdTypo]}>Email id</Text>
      <Text style={styles.sattarmemn566gmailcom}>Sattarmemn566@gmail.com</Text>
      <View style={[styles.iphone13ProMax2Item, styles.iphone13Layout]} />
      <View style={styles.parent}>
        <Text style={[styles.text, styles.textTypo]}>.</Text>
        <Text style={[styles.text1, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text4, styles.textTypo]}>.</Text>
        <Text style={[styles.text5, styles.textTypo]}>.</Text>
        <Text style={[styles.text6, styles.textTypo]}>.</Text>
        <Text style={[styles.text7, styles.textTypo]}>.</Text>
        <Text style={[styles.text8, styles.textTypo]}>.</Text>
        <Text style={[styles.text9, styles.text9Position]}>.</Text>
        <Text style={[styles.text10, styles.textTypo]}>.</Text>
        <Text style={[styles.text11, styles.textTypo]}>.</Text>
        <Text style={[styles.text12, styles.textTypo]}>.</Text>
        <Text style={[styles.text13, styles.textTypo]}>.</Text>
      </View>
      <Pressable
        style={styles.forgotPassword}
        onPress={() => navigation.navigate("IPhone13ProMax8")}
      >
        <Text style={[styles.forgotPassword1, styles.forgotPassword1Typo]}>
          forgot password?
        </Text>
      </Pressable>
      <Text style={[styles.dontHaveAnContainer, styles.forgotPassword1Typo]}>
        <Text style={styles.dontHaveAn}>dont have an account?</Text>
        <Text style={styles.registerNow}>{`register now `}</Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  unionIconPosition: {
    top: 0,
    left: 0,
  },
  groupChildLayout: {
    height: 50,
    width: 343,
    position: "absolute",
  },
  emailIdTypo: {
    color: Color.colorGray_600,
    textTransform: "uppercase",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  iphone13Layout: {
    height: 1,
    width: 339,
    borderTopWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  textTypo: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    top: 0,
  },
  text9Position: {
    left: 67,
    position: "absolute",
  },
  forgotPassword1Typo: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  unionIcon: {
    width: 0,
    height: 0,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorCrimson,
    left: 0,
    top: 0,
  },
  login: {
    top: 7,
    left: 138,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 740,
    left: 43,
  },
  or: {
    top: 429,
    left: 201,
    fontSize: FontSize.size_mini,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  password: {
    top: 594,
    left: 42,
  },
  iphone13ProMax2Child: {
    top: 653,
    left: 41,
    borderColor: Color.colorGray_500,
  },
  emailId: {
    top: 507,
    left: 43,
  },
  sattarmemn566gmailcom: {
    top: 534,
    color: Color.colorGray_300,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    left: 43,
    position: "absolute",
  },
  iphone13ProMax2Item: {
    top: 568,
    borderColor: Color.colorGray_700,
    left: 42,
  },
  text: {
    left: 0,
    position: "absolute",
  },
  text1: {
    left: 8,
    position: "absolute",
  },
  text2: {
    left: 17,
    position: "absolute",
  },
  text4: {
    left: 25,
    position: "absolute",
  },
  text5: {
    left: 34,
    position: "absolute",
  },
  text6: {
    left: 42,
    position: "absolute",
  },
  text7: {
    left: 51,
    position: "absolute",
  },
  text8: {
    left: 59,
    position: "absolute",
  },
  text9: {
    width: 16,
    fontSize: FontSize.size_13xl,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    top: 0,
  },
  text10: {
    left: 76,
    position: "absolute",
  },
  text11: {
    left: 84,
    position: "absolute",
  },
  text12: {
    left: 93,
    position: "absolute",
  },
  text13: {
    left: 101,
    position: "absolute",
  },
  parent: {
    top: 600,
    width: 117,
    height: 48,
    left: 42,
    position: "absolute",
  },
  forgotPassword1: {
    textTransform: "lowercase",
    color: Color.colorCrimson,
  },
  forgotPassword: {
    left: 251,
    top: 671,
    position: "absolute",
  },
  dontHaveAn: {
    color: Color.colorGray_800,
  },
  registerNow: {
    color: Color.colorCrimson,
  },
  dontHaveAnContainer: {
    top: 829,
    textTransform: "capitalize",
    left: 67,
    position: "absolute",
  },
  iphone13ProMax2: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax9;
