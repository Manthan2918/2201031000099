import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import GroupComponent1 from "../components/GroupComponent1";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone13ProMax3 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax8}>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector5.png")}
      />
      <Text style={styles.registerToFoodu}>Register to foodu</Text>
      <Text style={[styles.fullName, styles.passwordTypo]}>Full Name</Text>
      <Text style={[styles.manthan2918, styles.registerTypo]}>
        Manthan 2918
      </Text>
      <Text style={[styles.email, styles.passwordTypo]}>Email</Text>
      <Text style={[styles.mobileNumber, styles.passwordTypo]}>
        Mobile Number
      </Text>
      <Text style={[styles.password, styles.passwordTypo]}>Password</Text>
      <Text style={[styles.confirmPassword, styles.passwordTypo]}>
        Confirm Password
      </Text>
      <View
        style={[styles.iphone13ProMax8Child, styles.iphone13ChildPosition]}
      />
      <View
        style={[styles.iphone13ProMax8Item, styles.iphone13ChildPosition]}
      />
      <View
        style={[styles.iphone13ProMax8Inner, styles.iphone13ChildPosition]}
      />
      <View style={[styles.lineView, styles.iphone13ChildPosition]} />
      <View
        style={[styles.iphone13ProMax8Child1, styles.iphone13ChildPosition]}
      />
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("IPhone13ProMax1")}
      />
      <Text style={[styles.register, styles.registerTypo]}>Register</Text>
      <Text style={[styles.byRegisteringYouContainer, styles.containerTypo]}>
        <Text style={styles.byRegisteringYou}>By registering you agree to</Text>
        <Text style={styles.termsConditions}>{` Terms & conditions`}</Text>
      </Text>
      <Text style={[styles.andPrivacyPolicyContainer, styles.containerTypo]}>
        <Text style={styles.byRegisteringYou}> and</Text>
        <Text style={styles.termsConditions}> privacy Policy</Text>
        <Text style={styles.byRegisteringYou}> of the foodu</Text>
      </Text>
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection7.png")}
        wifi={require("../assets/wifi7.png")}
        cap={require("../assets/cap7.png")}
        groupViewPosition="absolute"
        groupViewWidth="98.58%"
        groupViewHeight="2.48%"
        groupViewTop="0.78%"
        groupViewRight="2.65%"
        groupViewBottom="96.74%"
        groupViewLeft="-1.23%"
        timeWidth="14.13%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.36%"
        batteryLeft="93.64%"
        borderWidth="90.51%"
        borderRight="9.49%"
        capIconWidth="5.47%"
        capIconLeft="94.53%"
        capIconRight="0%"
        capacityWidth="74.09%"
        capacityRight="17.52%"
        capacityLeft="8.39%"
      />
      <View style={[styles.parent, styles.groupLayout]}>
        <Text style={[styles.text, styles.textTypo]}>.</Text>
        <Text style={[styles.text1, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text4, styles.textTypo]}>.</Text>
        <Text style={[styles.text5, styles.textTypo]}>.</Text>
        <Text style={[styles.text6, styles.textTypo]}>.</Text>
        <Text style={[styles.text7, styles.textTypo]}>.</Text>
        <Text style={[styles.text8, styles.textTypo]}>.</Text>
        <Text style={[styles.text9, styles.textTypo]}>.</Text>
        <Text style={[styles.text10, styles.textTypo]}>.</Text>
        <Text style={[styles.text11, styles.textTypo]}>.</Text>
        <Text style={[styles.text12, styles.textTypo]}>.</Text>
        <Text style={[styles.text13, styles.textTypo]}>.</Text>
      </View>
      <View style={[styles.group, styles.groupLayout]}>
        <Text style={[styles.text, styles.textTypo]}>.</Text>
        <Text style={[styles.text1, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text2, styles.textTypo]}>.</Text>
        <Text style={[styles.text4, styles.textTypo]}>.</Text>
        <Text style={[styles.text5, styles.textTypo]}>.</Text>
        <Text style={[styles.text6, styles.textTypo]}>.</Text>
        <Text style={[styles.text7, styles.textTypo]}>.</Text>
        <Text style={[styles.text8, styles.textTypo]}>.</Text>
        <Text style={[styles.text9, styles.textTypo]}>.</Text>
        <Text style={[styles.text10, styles.textTypo]}>.</Text>
        <Text style={[styles.text11, styles.textTypo]}>.</Text>
        <Text style={[styles.text12, styles.textTypo]}>.</Text>
        <Text style={[styles.text13, styles.textTypo]}>.</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  passwordTypo: {
    color: Color.colorGray_1300,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_sm,
    left: "9.67%",
    textAlign: "left",
    position: "absolute",
  },
  registerTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  iphone13ChildPosition: {
    borderTopWidth: 1,
    borderColor: Color.colorGray_1400,
    borderStyle: "solid",
    left: "9.56%",
    right: "15.8%",
    width: "74.64%",
    height: "0.11%",
    position: "absolute",
  },
  containerTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    textAlign: "left",
    position: "absolute",
  },
  groupLayout: {
    height: 48,
    width: 117,
    position: "absolute",
  },
  textTypo: {
    width: 16,
    fontSize: FontSize.size_13xl,
    top: 0,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  vectorIcon: {
    height: "2.25%",
    width: "3.27%",
    top: "8.42%",
    right: "88.7%",
    bottom: "89.33%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "8.03%",
    position: "absolute",
    overflow: "hidden",
  },
  registerToFoodu: {
    width: "59.57%",
    top: "14.55%",
    fontSize: FontSize.size_9xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "left",
    color: Color.colorBlack,
    left: "8.03%",
    position: "absolute",
  },
  fullName: {
    width: "16.58%",
    top: "23.69%",
  },
  manthan2918: {
    width: "29.68%",
    top: "26.1%",
    color: Color.colorGray_1200,
    fontSize: FontSize.size_sm,
    left: "9.67%",
    fontWeight: "600",
  },
  email: {
    width: "9.35%",
    top: "32.22%",
  },
  mobileNumber: {
    width: "25.47%",
    top: "40.76%",
  },
  password: {
    width: "16.35%",
    top: "49.29%",
  },
  confirmPassword: {
    width: "30.6%",
    top: "57.82%",
  },
  iphone13ProMax8Child: {
    top: "28.8%",
    bottom: "71.09%",
  },
  iphone13ProMax8Item: {
    top: "37.41%",
    bottom: "62.48%",
  },
  iphone13ProMax8Inner: {
    top: "46.59%",
    bottom: "53.3%",
  },
  lineView: {
    top: "55.77%",
    bottom: "44.13%",
  },
  iphone13ProMax8Child1: {
    top: "64.95%",
    bottom: "34.95%",
  },
  rectanglePressable: {
    top: 671,
    left: 41,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorCrimson,
    width: 343,
    height: 50,
    position: "absolute",
  },
  register: {
    top: 681,
    left: 175,
    fontSize: FontSize.size_xl,
    color: Color.colorWhite,
  },
  byRegisteringYou: {
    color: Color.colorGray_1500,
  },
  termsConditions: {
    color: Color.colorCrimson,
  },
  byRegisteringYouContainer: {
    top: 764,
    left: 61,
  },
  andPrivacyPolicyContainer: {
    top: 794,
    left: 64,
  },
  text: {
    left: 0,
  },
  text1: {
    left: 8,
  },
  text2: {
    left: 17,
  },
  text4: {
    left: 25,
  },
  text5: {
    left: 34,
  },
  text6: {
    left: 42,
  },
  text7: {
    left: 51,
  },
  text8: {
    left: 59,
  },
  text9: {
    left: 67,
  },
  text10: {
    left: 76,
  },
  text11: {
    left: 84,
  },
  text12: {
    left: 93,
  },
  text13: {
    left: 101,
  },
  parent: {
    top: 467,
    left: 46,
  },
  group: {
    top: 550,
    left: 48,
  },
  iphone13ProMax8: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax3;
