import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import GroupComponent1 from "../components/GroupComponent1";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone13ProMax = () => {
  return (
    <View style={styles.iphone13ProMax11}>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector7.png")}
      />
      <Text style={[styles.forgotPassword, styles.passwordFlexBox]}>
        Forgot Password
      </Text>
      <Text
        style={[styles.pleaseEnterYour, styles.pleaseEnterYourTypo]}
      >{`Please enter your registered email or mobile
to reset your Password.`}</Text>
      <Text style={[styles.emailmobileNumber, styles.pleaseEnterYourTypo]}>
        Email/Mobile number
      </Text>
      <View style={styles.iphone13ProMax11Child} />
      <View style={styles.rectangleParent}>
        <View style={styles.groupChild} />
        <Text style={[styles.recoverPassword, styles.passwordFlexBox]}>
          Recover Password
        </Text>
      </View>
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection9.png")}
        wifi={require("../assets/wifi9.png")}
        cap={require("../assets/cap9.png")}
        groupViewPosition="absolute"
        groupViewWidth="97.19%"
        groupViewHeight="2.48%"
        groupViewTop="0.89%"
        groupViewRight="2.01%"
        groupViewBottom="96.63%"
        groupViewLeft="0.8%"
        timeWidth="14.12%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.35%"
        batteryLeft="93.65%"
        borderWidth="90.74%"
        borderRight="9.26%"
        capIconWidth="5.56%"
        capIconLeft="94.81%"
        capIconRight="-0.37%"
        capacityWidth="74.07%"
        capacityRight="17.78%"
        capacityLeft="8.15%"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  passwordFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  pleaseEnterYourTypo: {
    color: Color.colorGray_1700,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    left: "8.83%",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.34%",
    width: "3.18%",
    top: "9.4%",
    right: "87.99%",
    bottom: "88.26%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "8.83%",
    position: "absolute",
    overflow: "hidden",
  },
  forgotPassword: {
    width: "52.09%",
    top: "15.53%",
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_1600,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    left: "8.83%",
  },
  pleaseEnterYour: {
    width: "74.3%",
    top: "21.61%",
    fontSize: FontSize.size_sm,
  },
  emailmobileNumber: {
    width: "33.87%",
    top: "33.02%",
    fontSize: FontSize.size_smi,
  },
  iphone13ProMax11Child: {
    height: "0.11%",
    width: "74.89%",
    top: "38.62%",
    right: "16.76%",
    bottom: "61.27%",
    left: "8.35%",
    borderStyle: "solid",
    borderColor: Color.colorGray_1800,
    borderTopWidth: 1,
    position: "absolute",
  },
  groupChild: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorCrimson,
    position: "absolute",
    width: "100%",
  },
  recoverPassword: {
    width: "40.25%",
    top: "29.63%",
    left: "29.87%",
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_sm,
  },
  rectangleParent: {
    height: "5.54%",
    width: "76.01%",
    top: "45.55%",
    right: "13.31%",
    bottom: "48.91%",
    left: "10.68%",
    position: "absolute",
  },
  iphone13ProMax11: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 926,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone13ProMax;
