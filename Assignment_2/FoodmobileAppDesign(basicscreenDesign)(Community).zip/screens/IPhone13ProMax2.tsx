import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import GroupComponent1 from "../components/GroupComponent1";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone13ProMax2 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax10}>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector6.png")}
      />
      <Text style={[styles.forgotPassword, styles.passwordFlexBox]}>
        Forgot Password
      </Text>
      <Text
        style={[styles.pleaseEnterYour, styles.pleaseEnterYourTypo]}
      >{`Please enter your registered email or mobile
to reset your Password.`}</Text>
      <Text style={[styles.emailmobileNumber, styles.pleaseEnterYourTypo]}>
        Email/Mobile number
      </Text>
      <View style={styles.iphone13ProMax10Child} />
      <Pressable
        style={styles.rectangleParent}
        onPress={() => navigation.navigate("IPhone13ProMax")}
      >
        <View style={styles.groupChild} />
        <Text style={[styles.recoverPassword, styles.passwordFlexBox]}>
          Recover Password
        </Text>
      </Pressable>
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection8.png")}
        wifi={require("../assets/wifi8.png")}
        cap={require("../assets/cap8.png")}
        groupViewPosition="absolute"
        groupViewWidth="99.29%"
        groupViewHeight="2.48%"
        groupViewTop="0.99%"
        groupViewRight="1.92%"
        groupViewBottom="96.52%"
        groupViewLeft="-1.21%"
        timeWidth="14.12%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.36%"
        batteryLeft="93.64%"
        borderWidth="90.58%"
        borderRight="9.42%"
        capIconWidth="5.43%"
        capIconLeft="94.57%"
        capIconRight="0%"
        capacityWidth="73.91%"
        capacityRight="17.75%"
        capacityLeft="8.33%"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  passwordFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  pleaseEnterYourTypo: {
    color: Color.colorGray_1700,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    left: "8.83%",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.34%",
    width: "3.18%",
    top: "9.4%",
    right: "87.99%",
    bottom: "88.26%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "8.83%",
    position: "absolute",
    overflow: "hidden",
  },
  forgotPassword: {
    width: "52.09%",
    top: "15.53%",
    fontSize: FontSize.size_7xl,
    color: Color.colorGray_1600,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    left: "8.83%",
  },
  pleaseEnterYour: {
    width: "74.3%",
    top: "21.61%",
    fontSize: FontSize.size_sm,
  },
  emailmobileNumber: {
    width: "33.87%",
    top: "33.02%",
    fontSize: FontSize.size_smi,
  },
  iphone13ProMax10Child: {
    height: "0.11%",
    width: "74.89%",
    top: "38.62%",
    right: "16.76%",
    bottom: "61.27%",
    left: "8.35%",
    borderStyle: "solid",
    borderColor: Color.colorGray_1800,
    borderTopWidth: 1,
    position: "absolute",
  },
  groupChild: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorGainsboro_200,
    position: "absolute",
    width: "100%",
  },
  recoverPassword: {
    width: "40.25%",
    top: "29.63%",
    left: "29.87%",
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_sm,
  },
  rectangleParent: {
    height: "5.54%",
    width: "76.01%",
    top: "45.55%",
    right: "13.31%",
    bottom: "48.91%",
    left: "10.68%",
    position: "absolute",
  },
  iphone13ProMax10: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 926,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone13ProMax2;
