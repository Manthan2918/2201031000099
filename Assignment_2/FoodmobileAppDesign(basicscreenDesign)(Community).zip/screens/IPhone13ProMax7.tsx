import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import EmailFormContainer from "../components/EmailFormContainer";
import GroupComponent1 from "../components/GroupComponent1";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const IPhone13ProMax7 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax4}>
      <Text style={[styles.checkYouEmail, styles.weHaveSentTypo]}>
        Check you Email
      </Text>
      <Text
        style={[styles.weHaveSent, styles.weHaveSentTypo]}
      >{`we have sent you a reset password link 
      on ypur registered email address`}</Text>
      <EmailFormContainer
        onGroupPressablePress={() => navigation.navigate("IPhone13ProMax4")}
      />
      <Image
        style={styles.sendingEmailAtRocketSpeed}
        contentFit="cover"
        source={require("../assets/sending-email-at-rocket-speed.png")}
      />
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection4.png")}
        wifi={require("../assets/wifi4.png")}
        cap={require("../assets/cap4.png")}
        groupViewPosition="absolute"
        groupViewWidth="97.42%"
        groupViewHeight="2.48%"
        groupViewTop="0.97%"
        groupViewRight="2.58%"
        groupViewBottom="96.54%"
        groupViewLeft="0%"
        timeWidth="14.13%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.36%"
        batteryLeft="93.64%"
        borderWidth="90.41%"
        borderRight="9.59%"
        capIconWidth="5.54%"
        capIconLeft="94.46%"
        capIconRight="0%"
        capacityWidth="74.17%"
        capacityRight="17.71%"
        capacityLeft="8.12%"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  weHaveSentTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  checkYouEmail: {
    top: 475,
    left: 113,
    fontSize: FontSize.size_5xl,
    color: Color.colorBlack,
  },
  weHaveSent: {
    top: 529,
    left: 53,
    fontSize: FontSize.size_base,
    color: Color.colorGray_900,
  },
  sendingEmailAtRocketSpeed: {
    top: 63,
    left: 16,
    width: 395,
    height: 448,
    position: "absolute",
  },
  iphone13ProMax4: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax7;
