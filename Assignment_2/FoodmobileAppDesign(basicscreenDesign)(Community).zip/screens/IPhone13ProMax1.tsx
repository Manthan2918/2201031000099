import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import ContainerWrapper from "../components/ContainerWrapper";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import GroupComponent1 from "../components/GroupComponent1";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const IPhone13ProMax1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone13ProMax9}>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Text style={styles.enter4Digit}>{`Enter 4 digit code sent
                 To you`}</Text>
      <ContainerWrapper />
      <Pressable
        style={styles.iphone13ProMax9Child}
        onPress={() => navigation.navigate("IPhone13ProMax2")}
      />
      <Text style={styles.verify}>Verify</Text>
      <Text style={[styles.didntReceiveA, styles.resendCodeTypo]}>
        Didn’t receive a verification code?
      </Text>
      <Text style={[styles.resendCode, styles.resendCodeTypo]}>
        Resend code | Change Number
      </Text>
      <GroupComponent1
        cellularConnection={require("../assets/cellular-connection5.png")}
        wifi={require("../assets/wifi5.png")}
        cap={require("../assets/cap5.png")}
        groupViewPosition="absolute"
        groupViewWidth="97.42%"
        groupViewHeight="2.48%"
        groupViewTop="1.04%"
        groupViewRight="2.54%"
        groupViewBottom="96.48%"
        groupViewLeft="0.05%"
        timeWidth="14.13%"
        timeFontSize={14}
        cellularConnectionIconWidth={19}
        wifiIconWidth={17}
        batteryWidth="6.36%"
        batteryLeft="93.64%"
        borderWidth="90.41%"
        borderRight="9.59%"
        capIconWidth="5.54%"
        capIconLeft="94.46%"
        capIconRight="0%"
        capacityWidth="74.17%"
        capacityRight="17.71%"
        capacityLeft="8.12%"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  resendCodeTypo: {
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.25%",
    width: "3.27%",
    top: "7.88%",
    right: "84.43%",
    bottom: "89.87%",
    maxWidth: "100%",
    maxHeight: "100%",
    left: "12.3%",
    position: "absolute",
    overflow: "hidden",
  },
  enter4Digit: {
    width: "74.3%",
    top: "15.01%",
    fontSize: FontSize.size_9xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorBlack,
    textAlign: "left",
    left: "12.3%",
    position: "absolute",
  },
  iphone13ProMax9Child: {
    top: 425,
    left: 42,
    backgroundColor: Color.colorCrimson,
    width: 344,
    height: 56,
    position: "absolute",
  },
  verify: {
    top: 437,
    left: 182,
    fontSize: FontSize.size_3xl,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  didntReceiveA: {
    top: 520,
    left: 90,
    color: Color.colorGray_1500,
  },
  resendCode: {
    top: 551,
    left: 100,
    color: Color.colorCrimson,
  },
  iphone13ProMax9: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 926,
    overflow: "hidden",
  },
});

export default IPhone13ProMax1;
